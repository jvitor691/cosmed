import { useState } from "react";
import { faqItems } from "../../data/faq";
import { config } from "../../data/config";
import "./FAQ.css";

const FAQ = () => {
    const [open, setOpen] = useState(0);

    const items = faqItems.map((item) =>
        item.isPaymentMethods
            ? { ...item, answer: config.paymentMethods }
            : item
    );

    return (
        <section className="faq-section">
            <div className="container faq-container">
                <span className="eyebrow">DÚVIDAS</span>

                <h2>Perguntas frequentes</h2>

                <div className="faq-list">
                    {items.map((item, index) => (
                        <article
                            className={`faq-item ${open === index ? "active" : ""}`}
                            key={item.question}
                        >
                            <button
                                onClick={() =>
                                    setOpen(open === index ? null : index)
                                }
                            >
                                <span>{item.question}</span>
                                <span>{open === index ? "−" : "+"}</span>
                            </button>

                            {open === index && <p>{item.answer}</p>}
                        </article>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FAQ;