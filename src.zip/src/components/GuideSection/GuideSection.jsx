import { useState } from "react";
import "./guideSection.css";

import RoundCarousel from "../Carrosel/RoundCarousel";
import { slides } from "../../data/slides";
import { benefits } from "../../data/benefits";


const GuideSection = () => {
    const [current, setCurrent] = useState(0);

    const next = () => {
        setCurrent((value) => (value + 1) % slides.length);
    };

    const prev = () => {
        setCurrent((value) =>
            value === 0 ? slides.length - 1 : value - 1
        );
    };

    return (
        <section id="guia" className="guide-section">
            <div className="container">
                <div className="section-heading center light">
                    <span className="eyebrow">O QUE VOCÊ RECEBE</span>

                    <h2>Tudo isso dentro do Guia.</h2>

                    <p>
                        Veja páginas reais do material para entender exatamente o que você
                        vai receber.
                    </p>
                </div>

                <div className="guide-grid">
                    <div className="benefits-grid">
                        {benefits.map((benefit) => (
                            <article className="benefit-card" key={benefit.title}>
                                <span className="benefit-dot" />

                                <h3>{benefit.title}</h3>

                                <p>{benefit.description}</p>
                            </article>
                        ))}
                    </div>

                    <div className="guide-carousel">
                        <RoundCarousel
                            images={slides}
                            imageWidth={280}
                            imageHeight={410}
                            spacing={2.2}
                            speed={5}
                            direction="right"
                            drag={true}
                            sensitivity={1.4}
                            tilt={-5}
                            perspective={1800}
                            cornerRadius={18}
                        />
                    </div>
                </div>

                <div className="guide-flow">
                    <div>
                        <span>01</span>
                        <strong>Descubra sua trilha</strong>
                    </div>

                    <div>
                        <span>02</span>
                        <strong>Siga uma direção</strong>
                    </div>

                    <div>
                        <span>03</span>
                        <strong>Pratique e corrija</strong>
                    </div>

                    <div>
                        <span>04</span>
                        <strong>Ajuste e evolua</strong>
                    </div>
                </div>

                <div className="center">
                    <a href="#oferta" className="btn btn-yellow">
                        QUERO MEU GUIA DE ESTUDOS →
                    </a>
                </div>
            </div>
        </section>
    );
};

export default GuideSection;