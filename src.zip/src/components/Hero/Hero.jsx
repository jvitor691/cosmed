import WordGlobe from "../WordGlobe/WordGlobe";
import "./hero.css";

const Hero = () => {
    return (
        <section className="hero">
            <div className="container hero-grid">

                {/* LADO ESQUERDO */}
                <div className="hero-content">

                    <span className="hero-eyebrow">
                        GUIA DE ESTUDOS COSMED • ENEM 2026
                    </span>

                    <h1 className="hero-title">
                        Você não precisa estudar tudo.
                        <span>
                            Precisa saber o que fazer agora.
                        </span>
                    </h1>

                    <p className="hero-description">
                        Um guia prático para entender seu momento de estudo,
                        escolher sua trilha e seguir uma preparação possível
                        até o ENEM — com cronogramas, calendários, estratégias
                        e ferramentas reunidas em um só lugar.
                    </p>

                    <div className="hero-actions">
                        <a
                            href="#oferta"
                            className="btn btn-yellow hero-main-button"
                        >
                            QUERO COMEÇAR MINHA TRILHA
                            <span>→</span>
                        </a>

                        <a
                            href="#guia"
                            className="hero-secondary-link"
                        >
                            Ver o Guia por dentro
                        </a>
                    </div>

                    <div className="hero-badges">
                        <span>3 trilhas</span>
                        <span>100% digital</span>
                        <span>Acesso imediato</span>
                        <span>Cronogramas + calendários</span>
                    </div>
                </div>


                {/* LADO DIREITO — SUBSTITUI O HERO PRODUCT */}
                <div className="hero-globe-area">

                    <div className="hero-globe-glow" />

                    <div className="hero-globe">
                        <WordGlobe
                            word="COSMED            "
                            color="#FFC629"
                            speed={5}
                            fontSize={10}
                        />
                    </div>

                </div>

            </div>
        </section>
    );
};

export default Hero;