import { config } from "../../data/config";
import "./footer.css";
import logo from "../../assets/logo-cosmed.png";
import InstagramIcon from '@mui/icons-material/Instagram';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import EmailIcon from '@mui/icons-material/Email';
import { FaTiktok } from "react-icons/fa6";
import TextVaporize from "../TextVaporize/TextVaporize";


const Footer = () => {
    return (
        <footer className="footer">
            <div className="container">
                <div className="footer-content">
                    <div className="footer-brand">
                        <a href="#oferta" className="logo">
                            <img src={logo} alt="Cosmed" />
                        </a>

                        <div className="footer-vaporize">
                            <TextVaporize
                                texts={[
                                    "Estudar fica mais leve quando você sabe para onde ir."
                                ]}
                                color="#FFC629"
                                font={{
                                    fontFamily: "Manrope",
                                    variant: "Regular",
                                    fontWeight: 600,
                                    fontSize: 20,
                                    lineHeight: 1,
                                    letterSpacing: 0,
                                    textAlign: "center",
                                }}
                                spread={6}
                                density={8}
                                alignment="center"
                                tag="p"
                            />
                        </div>
                    </div>

                    <div className="footer-social">
                        <a
                            href={config.instagram}
                            target="_blank"
                            rel="noreferrer"
                            aria-label="Instagram"
                        >
                            <InstagramIcon />
                        </a>

                        <a
                            href={config.tiktok}
                            target="_blank"
                            rel="noreferrer"
                            aria-label="TikTok"
                        >
                            <FaTiktok />
                        </a>

                        <a
                            href={config.whatsapp}
                            target="_blank"
                            rel="noreferrer"
                            aria-label="WhatsApp"
                        >
                            <WhatsAppIcon />
                        </a>

                        <a
                            href={`mailto:${config.email}`}
                            aria-label="E-mail"
                        >
                            <EmailIcon />
                        </a>
                    </div>
                </div>

                <div className="footer-bottom">
                    <span>
                        © 2026 COSMED. Todos os direitos reservados.
                    </span>

                    <div className="footer-links">
                        <a href={config.privacyUrl}>Política de Privacidade</a>
                        <a href={config.termsUrl}>Termos de Uso</a>
                        <a href={config.supportUrl}>Suporte</a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;