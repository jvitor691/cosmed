import { trails } from "../../data/trails";
import "./trailsSection.css";

const TrailsSection = () => {
    return (
        <section className="section-light">
            <div className="container">
                <div className="section-heading center">
                    <span className="eyebrow dark">
                        COMECE DO PONTO EM QUE VOCÊ ESTÁ
                    </span>

                    <h2>Um só cronograma não funciona para todo mundo.</h2>

                    {/* <p>
                        Talvez você esteja começando agora, tenha estudado e perdido o
                        ritmo ou já tenha uma base e precise transformar esforço em mais
                        acertos.
                    </p> */}
                </div>

                <div className="pain-highlight">
                    <strong>
                        Se a sensação é de que ficou tarde, o objetivo não é recuperar tudo
                        de uma vez.
                    </strong>

                    <p>
                        É parar de gastar tempo tentando descobrir sozinho o que estudar,
                        como organizar e o que priorizar a partir de agora.
                    </p>
                </div>

                <div className="trails-grid">
                    {trails.map((trail) => (
                        <article key={trail.id} className={trail.className}>
                            <span>{trail.label}</span>
                            <h3>{trail.title}</h3>
                            <p>{trail.description}</p>
                        </article>
                    ))}
                </div>

                <p className="trail-note">
                    Não escolha a trilha que parece mais avançada.{" "}
                    <strong>Escolha aquela que representa seus estudos hoje.</strong>
                </p>
            </div>
        </section>
    );
};

export default TrailsSection;