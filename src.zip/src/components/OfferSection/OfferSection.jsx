import { config } from "../../data/config";
import { offerBenefits } from "../../data/offerBenefits";
import "./offerSection.css";

const OfferSection = () => {
    return (
        <section id="oferta" className="offer-section">
            <div className="container">
                <div className="section-heading center">
                    <span className="eyebrow dark">OFERTA DE LANÇAMENTO</span>

                    <h2>Comece agora com uma direção para a reta final.</h2>
                </div>

                <div className="offer-card">
                    <div className="offer-benefits">
                        <h3>Guia de Estudos COSMED</h3>

                        <div className="offer-list">
                            {offerBenefits.map((item) => (
                                <div key={item}>
                                    <span>✓</span>
                                    {item}
                                </div>
                            ))}
                        </div>
                    </div>

                    <div className="offer-price">
                        <span className="offer-tag">VALOR ESPECIAL DE LANÇAMENTO</span>

                        <p className="old-price">De {config.originalPrice}</p>

                        <strong className="price">{config.launchPrice}</strong>

                        <p>ou {config.installments}</p>

                        <a
                            href={config.productLink}
                            target="_blank"
                            rel="noreferrer"
                            className="btn btn-yellow btn-full"
                        >
                            QUERO COMEÇAR MINHA TRILHA →
                        </a>

                        <div className="checkout-info">
                            <span>🔒 Pagamento seguro</span>
                            <span>⚡ Acesso imediato</span>
                            <span>💻 100% digital</span>
                        </div>

                        <div className="guarantee">
                            <strong>7 dias de garantia</strong>

                            <p>
                                Se dentro desse período o material não fizer sentido para você,
                                o reembolso pode ser solicitado seguindo as condições da
                                plataforma.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default OfferSection;