import "./header.css";
import logo from "../../assets/logo-cosmed.png";


const Header = () => {
    const scrollToOffer = () => {
        document
            .getElementById("oferta")
            ?.scrollIntoView({ behavior: "smooth" });
    };

    return (
        <header className="header">
            <div className="container header-content">
                <a href="#" className="logo">
                    <img src={logo} alt="Cosmed" />
                </a>

                <div className="header-actions">
                    <a href="#guia" className="header-link">
                        Ver o Guia
                    </a>

                    <button className="btn btn-yellow btn-small" onClick={scrollToOffer}>
                        QUERO MEU GUIA
                    </button>
                </div>
            </div>
        </header>
    );
};

export default Header;