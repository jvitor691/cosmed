import thais from "../../assets/thais-cosmo-foto.jpg";
import "./about.css";

const About = () => {
    return (
        <section className="about-section">
            <div className="container about-grid">
                <div className="about-image">
                    <img src={thais} alt="Thaís Cosmo" />
                </div>

                <div>
                    <span className="eyebrow dark">
                        CRIADO POR QUEM VIVE ESSA ROTINA
                    </span>

                    <h2>Quem é Thaís Cosmo?</h2>

                    <p>
                        Thaís é vestibulanda de Medicina e idealizadora da COSMED. Depois
                        de anos de preparação, mudanças de método e prática, percebeu que
                        sua evolução aconteceu quando passou a estudar de forma mais
                        estratégica.
                    </p>

                    <p>
                        O Guia nasceu para reunir em um só lugar aquilo que muitos
                        vestibulandos passam horas tentando encontrar sozinhos: direção,
                        ferramentas, organização e um próximo passo possível.
                    </p>

                    <div className="stats">
                        <div>
                            <strong>158</strong>
                            <span>acertos no ENEM 2025</span>
                        </div>

                        <div>
                            <strong>42/45</strong>
                            <span>acertos em Matemática</span>
                        </div>

                        <div>
                            <strong>COSMED</strong>
                            <span>idealizadora do projeto</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default About;